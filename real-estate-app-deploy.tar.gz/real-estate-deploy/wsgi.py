"""
WSGI config for PythonAnywhere deployment
"""
import sys
import os

# Add your project directory to the Python path
path = '/home/yourusername/mysite'  # Change 'yourusername' to your actual username
if path not in sys.path:
    sys.path.insert(0, path)

# Import your Flask application
from app import app as application

if __name__ == "__main__":
    application.run()