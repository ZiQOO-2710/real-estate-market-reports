# PythonAnywhere 배포 가이드

## 1. 파일 업로드
1. PythonAnywhere 계정에 로그인
2. Files 탭에서 `/home/yourusername/mysite/` 디렉토리 생성
3. 압축 해제한 모든 파일을 해당 디렉토리에 업로드

## 2. 환경 변수 설정
1. `.env.example` 파일을 `.env`로 복사
2. `.env` 파일을 편집하여 실제 API 키와 URL 입력:
   ```
   SUPABASE_URL=https://your-project.supabase.co
   SUPABASE_KEY=your_anon_key
   KAKAO_REST_API_KEY=your_kakao_key
   FLASK_SECRET_KEY=your_secret_key
   ```

## 3. 패키지 설치
PythonAnywhere Bash 콘솔에서:
```bash
cd /home/yourusername/mysite
pip3.10 install --user -r requirements.txt
```

## 4. 웹 앱 설정
1. Web 탭에서 "Add a new web app" 클릭
2. Python 3.10 선택
3. Flask 선택
4. WSGI configuration file 경로를 다음과 같이 수정:
   `/home/yourusername/mysite/wsgi.py`

## 5. Static Files 설정
Web 탭의 Static files 섹션에서:
- URL: `/static/`
- Directory: `/home/yourusername/mysite/static/`

## 6. 웹 앱 실행
1. Web 탭에서 "Reload" 버튼 클릭
2. 제공된 URL로 접속하여 확인

## 주의사항
- PythonAnywhere 무료 계정에서는 파일 크기 제한이 있음
- uploads 폴더에 업로드된 파일들은 정기적으로 정리 필요
- 환경 변수는 절대 GitHub 등에 커밋하지 말 것